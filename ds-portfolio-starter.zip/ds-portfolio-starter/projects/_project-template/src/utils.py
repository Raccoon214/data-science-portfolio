from pathlib import Path

def project_paths():
    root = Path(__file__).resolve().parents[2]
    return {
        "root": root,
        "data_raw": root / "data" / "raw",
        "data_interim": root / "data" / "interim",
        "data_processed": root / "data" / "processed",
        "reports": root / "reports",
        "figures": root / "reports" / "figures",
        "models": root / "models",
    }
