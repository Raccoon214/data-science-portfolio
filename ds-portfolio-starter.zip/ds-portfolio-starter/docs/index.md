# Portfolio — Case Studies

Welcome to the case studies section. This page is published via GitHub Pages (Settings → Pages → build from `main`, folder `/docs`).

## Featured
- **Iris SVM:** Margin intuition, ROC/AUC, and decision boundaries — _coming soon_
- **Retail Churn:** Prioritizing recall where false negatives are costly — _coming soon_
- **Product Returns:** Interpreting Random Forest feature importances — _coming soon_

---

> Tip: Keep this page short and visual; link to dedicated pages per project.
