"""Quick notebook cleaner: strips large outputs to keep git diffs small."""
import json, sys

def clean(path):
    with open(path, 'r', encoding='utf-8') as f:
        nb = json.load(f)
    for cell in nb.get('cells', []):
        if cell.get('outputs'):
            cell['outputs'] = []
        if 'execution_count' in cell:
            cell['execution_count'] = None
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(nb, f, ensure_ascii=False, indent=1)

if __name__ == "__main__":
    for p in sys.argv[1:]:
        clean(p)
        print(f"Cleaned {p}")
